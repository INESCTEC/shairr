import * as i0 from '@angular/core';
import { InjectionToken, Injectable, Inject, EventEmitter, Component, Input, Output, makeEnvironmentProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import * as i2 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { ButtonDirective, CardComponent, CardHeaderComponent, CardBodyComponent, FormDirective, FormControlDirective, FormLabelDirective, SpinnerComponent, ColComponent, RowComponent } from '@coreui/angular';

const ANNOTATION_CONTEXT = new InjectionToken('ANNOTATION_CONTEXT');

class AnnotationService {
    context;
    constructor(context) {
        this.context = context;
    }
    async getEnums() {
        const response = await this.request('/enums');
        return response.json();
    }
    async getDatasets() {
        const response = await this.request('/dataset');
        const body = await response.json();
        if (Array.isArray(body)) {
            return body;
        }
        if (body &&
            typeof body === 'object' &&
            'datasets' in body &&
            Array.isArray(body.datasets)) {
            return body.datasets;
        }
        if (body &&
            typeof body === 'object' &&
            'results' in body &&
            Array.isArray(body.results)) {
            return body.results;
        }
        throw new Error('Unexpected dataset response from the API.');
    }
    async startAnnotation(request) {
        return this.request('/alignment', {
            method: 'POST',
            body: JSON.stringify(request),
        });
    }
    returnToHost(result) {
        void this.context.returnToHost(result);
    }
    async request(path, init = {}) {
        const token = await this.context.getAccessToken();
        const headers = new Headers(init.headers);
        headers.set('Authorization', `Bearer ${token}`);
        if (init.body && !(init.body instanceof FormData)) {
            headers.set('Content-Type', 'application/json');
        }
        const response = await fetch(`${this.context.apiUrl.replace(/\/$/, '')}${path}`, {
            ...init,
            headers,
        });
        if (!response.ok) {
            const message = (await response.text()) ||
                `Request failed with status ${response.status}`;
            throw new Error(message);
        }
        return response;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: AnnotationService, deps: [{ token: ANNOTATION_CONTEXT }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: AnnotationService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: AnnotationService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [ANNOTATION_CONTEXT]
                }] }] });

class AnnotationComponent {
    annotationService;
    datasets = [];
    annotationCompleted = new EventEmitter();
    annotationFailed = new EventEmitter();
    availableDatasets = [];
    selectedDatasetIds = new Set();
    datasetsLoading = false;
    enums = {
        receptor: [],
        sequence_mode: [],
        species: [],
        reference: [],
        quality_control_template: [],
        sequence_template: [],
    };
    selection = {
        campaign_id: '',
        project_id: '',
        sample_id: '',
        receptor: '',
        sequence_mode: '',
        species: '',
        reference: '',
        quality_control_template: '',
        sequence_template: '',
        workspace_id: 2354,
    };
    enumsLoading = false;
    annotationLoading = false;
    annotationLog = '';
    annotationResult = null;
    errorMessage = '';
    constructor(annotationService) {
        this.annotationService = annotationService;
    }
    ngOnInit() {
        void Promise.all([
            this.loadDatasets(),
            this.loadEnums(),
        ]);
    }
    async loadEnums() {
        this.enumsLoading = true;
        this.errorMessage = '';
        try {
            this.enums = await this.annotationService.getEnums();
            this.setInitialSelections();
        }
        catch (error) {
            this.errorMessage = this.errorText(error);
        }
        finally {
            this.enumsLoading = false;
        }
    }
    async submitAnnotation() {
        if (this.annotationLoading || this.datasets.length === 0) {
            return;
        }
        this.annotationLoading = true;
        this.annotationLog = '';
        this.annotationResult = null;
        this.errorMessage = '';
        const { workspace_id, ...annotationConfig } = this.selection;
        const request = {
            workspace_id,
            enpi_sequence_annotation_config: [
                {
                    ...annotationConfig,
                    dataset_ids: this.datasets.map(dataset => dataset.id),
                },
            ],
        };
        try {
            const response = await this.annotationService.startAnnotation(request);
            const result = await this.readAlignmentStream(response);
            this.annotationResult = result;
            this.annotationCompleted.emit(result);
        }
        catch (error) {
            this.errorMessage = this.errorText(error);
            this.annotationFailed.emit(error);
        }
        finally {
            this.annotationLoading = false;
        }
    }
    setInitialSelections() {
        this.selection.receptor =
            this.enums.receptor[0] ?? '';
        this.selection.sequence_mode =
            this.enums.sequence_mode[0] ?? '';
        this.selection.species =
            this.enums.species[0] ?? '';
        this.selection.reference =
            this.referenceOptions[0] ?? '';
        this.selection.quality_control_template =
            this.qualityControlTemplateOptions[0] ?? '';
        this.selection.sequence_template =
            this.sequenceTemplateOptions[0] ?? '';
    }
    get referenceOptions() {
        const selectedSpecies = this.speciesCategory(this.selection.species);
        return this.enums.reference.filter(reference => {
            const referenceSpecies = this.speciesCategory(reference);
            return (!selectedSpecies ||
                !referenceSpecies ||
                selectedSpecies === referenceSpecies);
        });
    }
    get sequenceTemplateOptions() {
        const selectedReceptor = this.receptorCategory(this.selection.receptor);
        return this.enums.sequence_template.filter(template => {
            const templateReceptor = this.receptorCategory(template);
            return (!selectedReceptor ||
                !templateReceptor ||
                selectedReceptor === templateReceptor);
        });
    }
    get qualityControlTemplateOptions() {
        const selectedMode = this.sequenceModeCategory(this.selection.sequence_mode);
        return this.enums.quality_control_template.filter(template => {
            const templateMode = this.sequenceModeCategory(template);
            return (!selectedMode ||
                !templateMode ||
                selectedMode === templateMode);
        });
    }
    get sequenceModeOptions() {
        const templateMode = this.sequenceModeCategory(this.selection.sequence_template);
        if (templateMode !== 'single-cell') {
            return this.enums.sequence_mode;
        }
        return this.enums.sequence_mode.filter(mode => this.sequenceModeCategory(mode) === 'single-cell');
    }
    onReceptorChange(receptor) {
        const currentTemplateMode = this.sequenceModeCategory(this.selection.sequence_template);
        this.selection.receptor = receptor;
        if (!this.sequenceTemplateOptions.includes(this.selection.sequence_template)) {
            this.selection.sequence_template =
                this.sequenceTemplateOptions.find(template => this.sequenceModeCategory(template) === currentTemplateMode) ?? this.sequenceTemplateOptions[0] ?? '';
        }
    }
    onSpeciesChange(species) {
        this.selection.species = species;
        this.selection.reference = this.validSelection(this.selection.reference, this.referenceOptions);
    }
    onSequenceModeChange(sequenceMode) {
        this.selection.sequence_mode = sequenceMode;
        this.selection.quality_control_template = this.validSelection(this.selection.quality_control_template, this.qualityControlTemplateOptions);
        this.selection.sequence_template = this.validSelection(this.selection.sequence_template, this.sequenceTemplateOptions);
    }
    onSequenceTemplateChange(sequenceTemplate) {
        this.selection.sequence_template = sequenceTemplate;
        if (this.sequenceModeCategory(sequenceTemplate) === 'single-cell') {
            this.selection.sequence_mode =
                this.enums.sequence_mode.find(mode => this.sequenceModeCategory(mode) === 'single-cell') ?? '';
            this.selection.quality_control_template = this.validSelection(this.selection.quality_control_template, this.qualityControlTemplateOptions);
        }
    }
    validSelection(currentValue, options) {
        return options.includes(currentValue)
            ? currentValue
            : options[0] ?? '';
    }
    receptorCategory(value) {
        if (/(^|[_\s-])bcr($|[_\s-])/i.test(value)) {
            return 'bcr';
        }
        if (/(^|[_\s-])tcr($|[_\s-])/i.test(value)) {
            return 'tcr';
        }
        return null;
    }
    speciesCategory(value) {
        if (/human|homo\s+sapiens/i.test(value)) {
            return 'human';
        }
        if (/mouse|mus\s+musculus/i.test(value)) {
            return 'mouse';
        }
        return null;
    }
    sequenceModeCategory(value) {
        if (/single[_\s-]*cell/i.test(value)) {
            return 'single-cell';
        }
        if (/bulk/i.test(value) ||
            /^default quality control template$/i.test(value)) {
            return 'bulk';
        }
        return null;
    }
    async readAlignmentStream(response) {
        if (!response.body) {
            throw new Error('The annotation response did not contain a stream.');
        }
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';
        let result = null;
        while (true) {
            const { done, value } = await reader.read();
            buffer += decoder.decode(value, {
                stream: !done,
            });
            const lines = buffer.split(/\r?\n/);
            buffer = lines.pop() ?? '';
            for (const line of lines) {
                result = this.processStreamLine(line, result);
            }
            if (done) {
                break;
            }
        }
        if (buffer.trim()) {
            result = this.processStreamLine(buffer, result);
        }
        if (!result) {
            throw new Error('Annotation finished without returning a dataset.');
        }
        return result;
    }
    processStreamLine(line, currentResult) {
        const value = line.trim();
        if (!value) {
            return currentResult;
        }
        this.annotationLog += `${value}\n`;
        try {
            const parsed = JSON.parse(value);
            if (this.isAnnotationResult(parsed)) {
                return parsed;
            }
        }
        catch {
        }
        return currentResult;
    }
    isAnnotationResult(value) {
        return (typeof value === 'object' &&
            value !== null &&
            'id' in value &&
            typeof value.id === 'number');
    }
    errorText(error) {
        return error instanceof Error
            ? error.message
            : 'The annotation failed.';
    }
    returnToRepository() {
        this.annotationService.returnToHost(this.annotationResult);
    }
    async loadDatasets() {
        // When a host embeds the component and provides datasets,
        // use those instead of loading the complete list.
        if (this.datasets.length > 0) {
            this.availableDatasets = [...this.datasets];
            for (const dataset of this.datasets) {
                this.selectedDatasetIds.add(dataset.id);
            }
            return;
        }
        this.datasetsLoading = true;
        this.errorMessage = '';
        try {
            this.availableDatasets =
                await this.annotationService.getDatasets();
        }
        catch (error) {
            this.errorMessage = this.errorText(error);
        }
        finally {
            this.datasetsLoading = false;
        }
    }
    isDatasetSelected(datasetId) {
        return this.selectedDatasetIds.has(datasetId);
    }
    toggleDataset(dataset) {
        if (this.selectedDatasetIds.has(dataset.id)) {
            this.selectedDatasetIds.delete(dataset.id);
        }
        else {
            this.selectedDatasetIds.add(dataset.id);
        }
        this.updateSelectedDatasets();
    }
    toggleAllDatasets() {
        if (this.allDatasetsSelected) {
            this.selectedDatasetIds.clear();
        }
        else {
            for (const dataset of this.availableDatasets) {
                this.selectedDatasetIds.add(dataset.id);
            }
        }
        this.updateSelectedDatasets();
    }
    get allDatasetsSelected() {
        return (this.availableDatasets.length > 0 &&
            this.availableDatasets.every(dataset => this.selectedDatasetIds.has(dataset.id)));
    }
    updateSelectedDatasets() {
        this.datasets = this.availableDatasets.filter(dataset => this.selectedDatasetIds.has(dataset.id));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: AnnotationComponent, deps: [{ token: AnnotationService }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.14", type: AnnotationComponent, isStandalone: true, selector: "annotation", inputs: { datasets: "datasets" }, outputs: { annotationCompleted: "annotationCompleted", annotationFailed: "annotationFailed" }, ngImport: i0, template: "<c-card>\r\n  <c-card-header>\r\n    <strong>Annotation</strong>\r\n  </c-card-header>\r\n\r\n  <c-card-body>\r\n    @if (datasetsLoading) {\r\n      <div class=\"loading-state\">\r\n        <c-spinner size=\"sm\" />\r\n        <span>Loading FASTQ files\u2026</span>\r\n      </div>\r\n    } @else if (availableDatasets.length === 0) {\r\n      <div class=\"empty-state\">\r\n        No FASTQ files are available for annotation.\r\n      </div>\r\n    } @else {\r\n      <div class=\"dataset-selection mb-4\">\r\n        <div class=\"dataset-selection-header\">\r\n          <label class=\"form-check\">\r\n            <input\r\n              class=\"form-check-input\"\r\n              type=\"checkbox\"\r\n              [checked]=\"allDatasetsSelected\"\r\n              (change)=\"toggleAllDatasets()\"\r\n            />\r\n\r\n            <span class=\"form-check-label\">\r\n              Select all FASTQ files\r\n            </span>\r\n          </label>\r\n\r\n          <small class=\"text-muted\">\r\n            {{ datasets.length }} selected\r\n          </small>\r\n        </div>\r\n\r\n        <div class=\"dataset-list\">\r\n          @for (dataset of availableDatasets; track dataset.id) {\r\n            <label class=\"dataset-row\">\r\n              <input\r\n                class=\"form-check-input\"\r\n                type=\"checkbox\"\r\n                [checked]=\"isDatasetSelected(dataset.id)\"\r\n                (change)=\"toggleDataset(dataset)\"\r\n              />\r\n\r\n              <span class=\"dataset-details\">\r\n                <strong>{{ dataset.filename }}</strong>\r\n\r\n                @if (\r\n                  dataset.line_count !== undefined ||\r\n                  dataset.filesize !== undefined\r\n                ) {\r\n                  <small>\r\n                    @if (dataset.line_count !== undefined) {\r\n                      {{ dataset.line_count }} lines\r\n                    }\r\n\r\n                    @if (\r\n                      dataset.line_count !== undefined &&\r\n                      dataset.filesize !== undefined\r\n                    ) {\r\n                      \u00B7\r\n                    }\r\n\r\n                    @if (dataset.filesize !== undefined) {\r\n                      {{ dataset.filesize }} bytes\r\n                    }\r\n                  </small>\r\n                }\r\n              </span>\r\n            </label>\r\n          }\r\n        </div>\r\n      </div>\r\n\r\n      @if (enumsLoading) {\r\n        <div class=\"loading-state\">\r\n          <c-spinner size=\"sm\" />\r\n          <span>Loading annotation settings\u2026</span>\n        </div>\r\n      } @else {\r\n        <form\r\n          cForm\r\n          #annotationForm=\"ngForm\"\n          (ngSubmit)=\"submitAnnotation()\"\n        >\r\n          <div class=\"annotation-form-grid\">\r\n            <div class=\"annotation-field\">\r\n              <label cLabel for=\"campaignId\">\r\n                Campaign ID\r\n              </label>\r\n\r\n              <input\r\n                id=\"campaignId\"\r\n                name=\"campaignId\"\r\n                cFormControl\r\n                required\r\n                [(ngModel)]=\"selection.campaign_id\"\r\n              />\r\n            </div>\r\n\r\n            <div class=\"annotation-field\">\r\n              <label cLabel for=\"projectId\">\r\n                Project ID\r\n              </label>\r\n\r\n              <input\r\n                id=\"projectId\"\r\n                name=\"projectId\"\r\n                cFormControl\r\n                required\r\n                [(ngModel)]=\"selection.project_id\"\r\n              />\r\n            </div>\r\n\r\n            <div class=\"annotation-field\">\r\n              <label cLabel for=\"sampleId\">\r\n                Sample ID\r\n              </label>\r\n\r\n              <input\r\n                id=\"sampleId\"\r\n                name=\"sampleId\"\r\n                cFormControl\r\n                required\r\n                [(ngModel)]=\"selection.sample_id\"\r\n              />\r\n            </div>\r\n\r\n            <div class=\"annotation-field\">\r\n              <label cLabel for=\"receptor\">\r\n                Receptor\r\n              </label>\r\n\r\n              <select\r\n                id=\"receptor\"\r\n                name=\"receptor\"\r\n                class=\"form-select\"\n                required\n                [(ngModel)]=\"selection.receptor\"\n                (ngModelChange)=\"onReceptorChange($event)\"\n              >\r\n                @for (value of enums.receptor; track value) {\r\n                  <option [value]=\"value\">\r\n                    {{ value }}\r\n                  </option>\r\n                }\r\n              </select>\r\n            </div>\r\n\r\n            <div class=\"annotation-field\">\r\n              <label cLabel for=\"species\">\r\n                Species\r\n              </label>\r\n\r\n              <select\r\n                id=\"species\"\r\n                name=\"species\"\r\n                class=\"form-select\"\n                required\n                [(ngModel)]=\"selection.species\"\n                (ngModelChange)=\"onSpeciesChange($event)\"\n              >\r\n                @for (value of enums.species; track value) {\r\n                  <option [value]=\"value\">\r\n                    {{ value }}\r\n                  </option>\r\n                }\r\n              </select>\r\n            </div>\r\n\r\n            <div class=\"annotation-field\">\r\n              <label cLabel for=\"reference\">\r\n                Reference\r\n              </label>\r\n\r\n              <select\r\n                id=\"reference\"\r\n                name=\"reference\"\r\n                class=\"form-select\"\r\n                required\r\n                [(ngModel)]=\"selection.reference\"\r\n              >\r\n                @for (value of referenceOptions; track value) {\n                  <option [value]=\"value\">\r\n                    {{ value }}\r\n                  </option>\r\n                }\r\n              </select>\r\n            </div>\r\n\r\n            <div class=\"annotation-field\">\r\n              <label cLabel for=\"qualityControl\">\r\n                Quality-control template\r\n              </label>\r\n\r\n              <select\r\n                id=\"qualityControl\"\r\n                name=\"qualityControl\"\r\n                class=\"form-select\"\r\n                required\r\n                [(ngModel)]=\"\r\n                  selection.quality_control_template\r\n                \"\r\n              >\r\n                @for (\r\n                  value of qualityControlTemplateOptions;\n                  track value\r\n                ) {\r\n                  <option [value]=\"value\">\r\n                    {{ value }}\r\n                  </option>\r\n                }\r\n              </select>\r\n            </div>\r\n\r\n            <div class=\"annotation-field\">\r\n              <label cLabel for=\"sequenceTemplate\">\r\n                Sequence template\r\n              </label>\r\n\r\n              <select\r\n                id=\"sequenceTemplate\"\r\n                name=\"sequenceTemplate\"\r\n                class=\"form-select\"\n                required\n                [(ngModel)]=\"selection.sequence_template\"\n                (ngModelChange)=\"onSequenceTemplateChange($event)\"\n              >\r\n                @for (\r\n                  value of sequenceTemplateOptions;\n                  track value\r\n                ) {\r\n                  <option [value]=\"value\">\r\n                    {{ value }}\r\n                  </option>\r\n                }\r\n              </select>\r\n            </div>\r\n\r\n            <div class=\"annotation-field\">\r\n              <label cLabel for=\"sequenceMode\">\r\n                Sequence mode\r\n              </label>\r\n\r\n              <select\r\n                id=\"sequenceMode\"\r\n                name=\"sequenceMode\"\r\n                class=\"form-select\"\n                required\n                [(ngModel)]=\"selection.sequence_mode\"\n                (ngModelChange)=\"onSequenceModeChange($event)\"\n              >\r\n                @for (\r\n                  value of sequenceModeOptions;\n                  track value\r\n                ) {\r\n                  <option [value]=\"value\">\r\n                    {{ value }}\r\n                  </option>\r\n                }\r\n              </select>\r\n            </div>\r\n          </div>\r\n\r\n          <button\r\n            cButton\r\n            color=\"primary\"\r\n            type=\"submit\"\r\n            class=\"mt-4\"\r\n            [disabled]=\"\r\n              annotationLoading ||\r\n              annotationForm.invalid ||\n              datasets.length === 0\r\n            \"\r\n          >\r\n            @if (annotationLoading) {\r\n              <c-spinner size=\"sm\" class=\"me-2\" />\r\n            }\r\n\r\n            Annotate\r\n          </button>\r\n        </form>\r\n      }\r\n\r\n      @if (errorMessage) {\r\n        <div\r\n          class=\"alert alert-danger mt-3\"\r\n          role=\"alert\"\r\n        >\r\n          {{ errorMessage }}\r\n        </div>\r\n      }\r\n\r\n      @if (annotationResult) {\n        <div\n          class=\"alert alert-success mt-3\"\n          role=\"status\"\n        >\n          <strong>Annotation completed successfully.</strong>\n\n          <p class=\"mb-0 mt-2\">\n            Dataset {{ annotationResult.id }}\n            @if (annotationResult.filename) {\n              was created as {{ annotationResult.filename }}.\n            } @else {\n              was created.\n            }\n          </p>\n\n          <button\n            cButton\n            color=\"primary\"\n            type=\"button\"\n            class=\"mt-3\"\n            (click)=\"returnToRepository()\"\n          >\n            Back to repository\n          </button>\n        </div>\n      }\n\n      @if (annotationLog && !annotationResult) {\n        <div class=\"annotation-log mt-4\">\n          <strong>Annotation progress</strong>\n          <pre>{{ annotationLog }}</pre>\n        </div>\n      }\n    }\r\n  </c-card-body>\r\n</c-card>\n", styles: [".empty-state{display:flex;min-height:8rem;align-items:center;justify-content:center;color:var(--cui-secondary-color);text-align:center}.loading-state{display:flex;min-height:6rem;gap:.75rem;align-items:center;justify-content:center;color:var(--cui-secondary-color)}.selected-files{display:flex;flex-wrap:wrap;gap:.5rem}.selected-file{display:inline-flex;flex-direction:column;padding:.625rem .75rem;border:1px solid var(--cui-border-color);border-radius:var(--cui-border-radius);background:var(--cui-tertiary-bg)}.selected-file small{margin-top:.125rem;opacity:.8}.selected-file-name{font-size:.875rem;font-weight:600}.annotation-log pre{max-height:18rem;margin:.5rem 0 0;padding:.75rem;border:1px solid var(--cui-border-color);border-radius:var(--cui-border-radius);background:var(--cui-tertiary-bg);white-space:pre-wrap;overflow:auto}.dataset-selection{border:1px solid var(--cui-border-color);border-radius:var(--cui-border-radius);overflow:hidden}.dataset-selection-header{display:flex;align-items:center;justify-content:space-between;padding:.75rem 1rem;border-bottom:1px solid var(--cui-border-color);background:var(--cui-tertiary-bg)}.dataset-list{max-height:22rem;overflow-y:auto}.dataset-row{display:flex;gap:.75rem;align-items:flex-start;padding:.75rem 1rem;border-bottom:1px solid var(--cui-border-color);cursor:pointer}.dataset-row:last-child{border-bottom:0}.dataset-row:hover{background:var(--cui-tertiary-bg)}.dataset-row .form-check-input{flex:0 0 auto;margin-top:.2rem}.dataset-details{display:flex;flex-direction:column;min-width:0}.dataset-details strong{overflow-wrap:anywhere}.dataset-details small{margin-top:.125rem;color:var(--cui-secondary-color)}.annotation-form-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:1rem}.annotation-field{display:flex;flex-direction:column;min-width:0}.annotation-field label{margin-bottom:.375rem}.annotation-field input,.annotation-field select{width:100%}@media (max-width: 991.98px){.annotation-form-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}@media (max-width: 767.98px){.annotation-form-grid{grid-template-columns:1fr}}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i2.NgSelectOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.ɵNgSelectMultipleOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2.SelectControlValueAccessor, selector: "select:not([multiple])[formControlName],select:not([multiple])[formControl],select:not([multiple])[ngModel]", inputs: ["compareWith"] }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: i2.NgForm, selector: "form:not([ngNoForm]):not([formGroup]),ng-form,[ngForm]", inputs: ["ngFormOptions"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: ButtonDirective, selector: "[cButton]", inputs: ["active", "color", "disabled", "shape", "size", "type", "variant"], exportAs: ["cButton"] }, { kind: "component", type: CardComponent, selector: "c-card, [c-card]", inputs: ["color", "textColor", "textBgColor"] }, { kind: "component", type: CardHeaderComponent, selector: "c-card-header, [c-card-header]" }, { kind: "component", type: CardBodyComponent, selector: "c-card-body, [c-card-body]" }, { kind: "directive", type: FormDirective, selector: "form[cForm]", inputs: ["validated"] }, { kind: "directive", type: FormControlDirective, selector: "input[cFormControl], textarea[cFormControl]", inputs: ["sizing", "valid", "type", "plaintext"] }, { kind: "directive", type: FormLabelDirective, selector: "[cLabel]", inputs: ["cLabel", "sizing"] }, { kind: "component", type: SpinnerComponent, selector: "c-spinner", inputs: ["color", "label", "size", "variant", "role"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: AnnotationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'annotation', standalone: true, imports: [
                        CommonModule,
                        FormsModule,
                        ButtonDirective,
                        CardComponent,
                        CardHeaderComponent,
                        CardBodyComponent,
                        ColComponent,
                        RowComponent,
                        FormDirective,
                        FormControlDirective,
                        FormLabelDirective,
                        SpinnerComponent,
                    ], template: "<c-card>\r\n  <c-card-header>\r\n    <strong>Annotation</strong>\r\n  </c-card-header>\r\n\r\n  <c-card-body>\r\n    @if (datasetsLoading) {\r\n      <div class=\"loading-state\">\r\n        <c-spinner size=\"sm\" />\r\n        <span>Loading FASTQ files\u2026</span>\r\n      </div>\r\n    } @else if (availableDatasets.length === 0) {\r\n      <div class=\"empty-state\">\r\n        No FASTQ files are available for annotation.\r\n      </div>\r\n    } @else {\r\n      <div class=\"dataset-selection mb-4\">\r\n        <div class=\"dataset-selection-header\">\r\n          <label class=\"form-check\">\r\n            <input\r\n              class=\"form-check-input\"\r\n              type=\"checkbox\"\r\n              [checked]=\"allDatasetsSelected\"\r\n              (change)=\"toggleAllDatasets()\"\r\n            />\r\n\r\n            <span class=\"form-check-label\">\r\n              Select all FASTQ files\r\n            </span>\r\n          </label>\r\n\r\n          <small class=\"text-muted\">\r\n            {{ datasets.length }} selected\r\n          </small>\r\n        </div>\r\n\r\n        <div class=\"dataset-list\">\r\n          @for (dataset of availableDatasets; track dataset.id) {\r\n            <label class=\"dataset-row\">\r\n              <input\r\n                class=\"form-check-input\"\r\n                type=\"checkbox\"\r\n                [checked]=\"isDatasetSelected(dataset.id)\"\r\n                (change)=\"toggleDataset(dataset)\"\r\n              />\r\n\r\n              <span class=\"dataset-details\">\r\n                <strong>{{ dataset.filename }}</strong>\r\n\r\n                @if (\r\n                  dataset.line_count !== undefined ||\r\n                  dataset.filesize !== undefined\r\n                ) {\r\n                  <small>\r\n                    @if (dataset.line_count !== undefined) {\r\n                      {{ dataset.line_count }} lines\r\n                    }\r\n\r\n                    @if (\r\n                      dataset.line_count !== undefined &&\r\n                      dataset.filesize !== undefined\r\n                    ) {\r\n                      \u00B7\r\n                    }\r\n\r\n                    @if (dataset.filesize !== undefined) {\r\n                      {{ dataset.filesize }} bytes\r\n                    }\r\n                  </small>\r\n                }\r\n              </span>\r\n            </label>\r\n          }\r\n        </div>\r\n      </div>\r\n\r\n      @if (enumsLoading) {\r\n        <div class=\"loading-state\">\r\n          <c-spinner size=\"sm\" />\r\n          <span>Loading annotation settings\u2026</span>\n        </div>\r\n      } @else {\r\n        <form\r\n          cForm\r\n          #annotationForm=\"ngForm\"\n          (ngSubmit)=\"submitAnnotation()\"\n        >\r\n          <div class=\"annotation-form-grid\">\r\n            <div class=\"annotation-field\">\r\n              <label cLabel for=\"campaignId\">\r\n                Campaign ID\r\n              </label>\r\n\r\n              <input\r\n                id=\"campaignId\"\r\n                name=\"campaignId\"\r\n                cFormControl\r\n                required\r\n                [(ngModel)]=\"selection.campaign_id\"\r\n              />\r\n            </div>\r\n\r\n            <div class=\"annotation-field\">\r\n              <label cLabel for=\"projectId\">\r\n                Project ID\r\n              </label>\r\n\r\n              <input\r\n                id=\"projectId\"\r\n                name=\"projectId\"\r\n                cFormControl\r\n                required\r\n                [(ngModel)]=\"selection.project_id\"\r\n              />\r\n            </div>\r\n\r\n            <div class=\"annotation-field\">\r\n              <label cLabel for=\"sampleId\">\r\n                Sample ID\r\n              </label>\r\n\r\n              <input\r\n                id=\"sampleId\"\r\n                name=\"sampleId\"\r\n                cFormControl\r\n                required\r\n                [(ngModel)]=\"selection.sample_id\"\r\n              />\r\n            </div>\r\n\r\n            <div class=\"annotation-field\">\r\n              <label cLabel for=\"receptor\">\r\n                Receptor\r\n              </label>\r\n\r\n              <select\r\n                id=\"receptor\"\r\n                name=\"receptor\"\r\n                class=\"form-select\"\n                required\n                [(ngModel)]=\"selection.receptor\"\n                (ngModelChange)=\"onReceptorChange($event)\"\n              >\r\n                @for (value of enums.receptor; track value) {\r\n                  <option [value]=\"value\">\r\n                    {{ value }}\r\n                  </option>\r\n                }\r\n              </select>\r\n            </div>\r\n\r\n            <div class=\"annotation-field\">\r\n              <label cLabel for=\"species\">\r\n                Species\r\n              </label>\r\n\r\n              <select\r\n                id=\"species\"\r\n                name=\"species\"\r\n                class=\"form-select\"\n                required\n                [(ngModel)]=\"selection.species\"\n                (ngModelChange)=\"onSpeciesChange($event)\"\n              >\r\n                @for (value of enums.species; track value) {\r\n                  <option [value]=\"value\">\r\n                    {{ value }}\r\n                  </option>\r\n                }\r\n              </select>\r\n            </div>\r\n\r\n            <div class=\"annotation-field\">\r\n              <label cLabel for=\"reference\">\r\n                Reference\r\n              </label>\r\n\r\n              <select\r\n                id=\"reference\"\r\n                name=\"reference\"\r\n                class=\"form-select\"\r\n                required\r\n                [(ngModel)]=\"selection.reference\"\r\n              >\r\n                @for (value of referenceOptions; track value) {\n                  <option [value]=\"value\">\r\n                    {{ value }}\r\n                  </option>\r\n                }\r\n              </select>\r\n            </div>\r\n\r\n            <div class=\"annotation-field\">\r\n              <label cLabel for=\"qualityControl\">\r\n                Quality-control template\r\n              </label>\r\n\r\n              <select\r\n                id=\"qualityControl\"\r\n                name=\"qualityControl\"\r\n                class=\"form-select\"\r\n                required\r\n                [(ngModel)]=\"\r\n                  selection.quality_control_template\r\n                \"\r\n              >\r\n                @for (\r\n                  value of qualityControlTemplateOptions;\n                  track value\r\n                ) {\r\n                  <option [value]=\"value\">\r\n                    {{ value }}\r\n                  </option>\r\n                }\r\n              </select>\r\n            </div>\r\n\r\n            <div class=\"annotation-field\">\r\n              <label cLabel for=\"sequenceTemplate\">\r\n                Sequence template\r\n              </label>\r\n\r\n              <select\r\n                id=\"sequenceTemplate\"\r\n                name=\"sequenceTemplate\"\r\n                class=\"form-select\"\n                required\n                [(ngModel)]=\"selection.sequence_template\"\n                (ngModelChange)=\"onSequenceTemplateChange($event)\"\n              >\r\n                @for (\r\n                  value of sequenceTemplateOptions;\n                  track value\r\n                ) {\r\n                  <option [value]=\"value\">\r\n                    {{ value }}\r\n                  </option>\r\n                }\r\n              </select>\r\n            </div>\r\n\r\n            <div class=\"annotation-field\">\r\n              <label cLabel for=\"sequenceMode\">\r\n                Sequence mode\r\n              </label>\r\n\r\n              <select\r\n                id=\"sequenceMode\"\r\n                name=\"sequenceMode\"\r\n                class=\"form-select\"\n                required\n                [(ngModel)]=\"selection.sequence_mode\"\n                (ngModelChange)=\"onSequenceModeChange($event)\"\n              >\r\n                @for (\r\n                  value of sequenceModeOptions;\n                  track value\r\n                ) {\r\n                  <option [value]=\"value\">\r\n                    {{ value }}\r\n                  </option>\r\n                }\r\n              </select>\r\n            </div>\r\n          </div>\r\n\r\n          <button\r\n            cButton\r\n            color=\"primary\"\r\n            type=\"submit\"\r\n            class=\"mt-4\"\r\n            [disabled]=\"\r\n              annotationLoading ||\r\n              annotationForm.invalid ||\n              datasets.length === 0\r\n            \"\r\n          >\r\n            @if (annotationLoading) {\r\n              <c-spinner size=\"sm\" class=\"me-2\" />\r\n            }\r\n\r\n            Annotate\r\n          </button>\r\n        </form>\r\n      }\r\n\r\n      @if (errorMessage) {\r\n        <div\r\n          class=\"alert alert-danger mt-3\"\r\n          role=\"alert\"\r\n        >\r\n          {{ errorMessage }}\r\n        </div>\r\n      }\r\n\r\n      @if (annotationResult) {\n        <div\n          class=\"alert alert-success mt-3\"\n          role=\"status\"\n        >\n          <strong>Annotation completed successfully.</strong>\n\n          <p class=\"mb-0 mt-2\">\n            Dataset {{ annotationResult.id }}\n            @if (annotationResult.filename) {\n              was created as {{ annotationResult.filename }}.\n            } @else {\n              was created.\n            }\n          </p>\n\n          <button\n            cButton\n            color=\"primary\"\n            type=\"button\"\n            class=\"mt-3\"\n            (click)=\"returnToRepository()\"\n          >\n            Back to repository\n          </button>\n        </div>\n      }\n\n      @if (annotationLog && !annotationResult) {\n        <div class=\"annotation-log mt-4\">\n          <strong>Annotation progress</strong>\n          <pre>{{ annotationLog }}</pre>\n        </div>\n      }\n    }\r\n  </c-card-body>\r\n</c-card>\n", styles: [".empty-state{display:flex;min-height:8rem;align-items:center;justify-content:center;color:var(--cui-secondary-color);text-align:center}.loading-state{display:flex;min-height:6rem;gap:.75rem;align-items:center;justify-content:center;color:var(--cui-secondary-color)}.selected-files{display:flex;flex-wrap:wrap;gap:.5rem}.selected-file{display:inline-flex;flex-direction:column;padding:.625rem .75rem;border:1px solid var(--cui-border-color);border-radius:var(--cui-border-radius);background:var(--cui-tertiary-bg)}.selected-file small{margin-top:.125rem;opacity:.8}.selected-file-name{font-size:.875rem;font-weight:600}.annotation-log pre{max-height:18rem;margin:.5rem 0 0;padding:.75rem;border:1px solid var(--cui-border-color);border-radius:var(--cui-border-radius);background:var(--cui-tertiary-bg);white-space:pre-wrap;overflow:auto}.dataset-selection{border:1px solid var(--cui-border-color);border-radius:var(--cui-border-radius);overflow:hidden}.dataset-selection-header{display:flex;align-items:center;justify-content:space-between;padding:.75rem 1rem;border-bottom:1px solid var(--cui-border-color);background:var(--cui-tertiary-bg)}.dataset-list{max-height:22rem;overflow-y:auto}.dataset-row{display:flex;gap:.75rem;align-items:flex-start;padding:.75rem 1rem;border-bottom:1px solid var(--cui-border-color);cursor:pointer}.dataset-row:last-child{border-bottom:0}.dataset-row:hover{background:var(--cui-tertiary-bg)}.dataset-row .form-check-input{flex:0 0 auto;margin-top:.2rem}.dataset-details{display:flex;flex-direction:column;min-width:0}.dataset-details strong{overflow-wrap:anywhere}.dataset-details small{margin-top:.125rem;color:var(--cui-secondary-color)}.annotation-form-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:1rem}.annotation-field{display:flex;flex-direction:column;min-width:0}.annotation-field label{margin-bottom:.375rem}.annotation-field input,.annotation-field select{width:100%}@media (max-width: 991.98px){.annotation-form-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}@media (max-width: 767.98px){.annotation-form-grid{grid-template-columns:1fr}}\n"] }]
        }], ctorParameters: () => [{ type: AnnotationService }], propDecorators: { datasets: [{
                type: Input
            }], annotationCompleted: [{
                type: Output
            }], annotationFailed: [{
                type: Output
            }] } });

function provideAnnotation(context) {
    return makeEnvironmentProviders([
        {
            provide: ANNOTATION_CONTEXT,
            useValue: context,
        },
    ]);
}

/*
 * Public API surface of annotation.
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ANNOTATION_CONTEXT, AnnotationComponent, AnnotationService, provideAnnotation };
//# sourceMappingURL=annotation.mjs.map
