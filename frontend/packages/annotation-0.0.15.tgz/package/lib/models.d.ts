export interface AnnotationDataset {
    id: number;
    filename: string;
    filesize?: number;
    line_count?: number;
}
export interface AnnotationOptions {
    receptor: string[];
    sequence_mode: string[];
    species: string[];
    reference: string[];
    quality_control_template: string[];
    sequence_template: string[];
}
export interface AnnotationSelection {
    campaign_id: string;
    project_id: string;
    sample_id: string;
    receptor: string;
    sequence_mode: string;
    species: string;
    reference: string;
    quality_control_template: string;
    sequence_template: string;
    workspace_id: number;
}
export type SequenceAnnotationConfig = Omit<AnnotationSelection, 'workspace_id'> & {
    dataset_ids: number[];
};
export interface AnnotationRequest {
    workspace_id: number;
    enpi_sequence_annotation_config: SequenceAnnotationConfig[];
}
export interface AnnotationResult {
    id: number;
    filename?: string;
    [key: string]: unknown;
}
