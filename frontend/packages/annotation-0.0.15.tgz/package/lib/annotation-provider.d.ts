import { EnvironmentProviders } from '@angular/core';
import { AnnotationContext } from './annotation-context';
export declare function provideAnnotation(context: AnnotationContext): EnvironmentProviders;
