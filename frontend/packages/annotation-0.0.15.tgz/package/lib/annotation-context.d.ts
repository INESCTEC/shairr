import { InjectionToken } from '@angular/core';
import { AnnotationResult } from './models';
export interface AnnotationContext {
    apiUrl: string;
    getAccessToken: () => Promise<string>;
    returnToHost: (result: AnnotationResult | null) => void | Promise<unknown>;
}
export declare const ANNOTATION_CONTEXT: InjectionToken<AnnotationContext>;
