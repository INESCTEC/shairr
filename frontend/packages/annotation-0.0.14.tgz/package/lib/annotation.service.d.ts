import { AnnotationRequest, AnnotationDataset, AnnotationOptions } from './models';
import { AnnotationContext } from './annotation-context';
import * as i0 from "@angular/core";
export declare class AnnotationService {
    private readonly context;
    constructor(context: AnnotationContext);
    getEnums(): Promise<AnnotationOptions>;
    getDatasets(): Promise<AnnotationDataset[]>;
    startAnnotation(request: AnnotationRequest): Promise<Response>;
    returnToHost(): void;
    private request;
    static ɵfac: i0.ɵɵFactoryDeclaration<AnnotationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AnnotationService>;
}
