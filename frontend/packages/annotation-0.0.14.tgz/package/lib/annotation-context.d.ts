import { InjectionToken } from '@angular/core';
export interface AnnotationContext {
    apiUrl: string;
    getAccessToken: () => Promise<string>;
    returnToHost: () => void | Promise<unknown>;
}
export declare const ANNOTATION_CONTEXT: InjectionToken<AnnotationContext>;
